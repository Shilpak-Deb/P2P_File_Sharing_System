#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "client.h"

using namespace std;

//create_user
void create_user(int client_socket, vector<string> command_list) {
    if(command_list.size() < 3) {
        cerr << "./client: create_user: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 3) {
        cerr << "./client: create_user: Too many arguments!" << endl;
        return;
    }
    //Writing message to tracker
    string message = listening_socket + " CREATE_USER " + command_list[1] + " " + command_list[2];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
        
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "MULTIPLE USERS") cerr << "./client: Multiple users cannot be created from same client!" << endl;
    if(ack == "USER EXISTS") cerr << "./client: User already exists!" << endl;
    if(ack == "USER ADDED") cout << "User created successfully!" << endl;

    //cout << ack << endl;   
}

//login
void login(int client_socket, vector<string> command_list) {
    if(command_list.size() < 3) {
        cerr << "./client: login: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 3) {
        cerr << "./client: login: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LOGIN " + command_list[1] + " " + command_list[2];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
        
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "USER NOT EXISTS") cerr << "./client: User does not exist!" << endl;
    if(ack == "INVALID CREDENTIALS") cerr << "./client: Invalid Credentials!" << endl;
    if(ack == "WRONG PASSWORD") cerr << "./client: Incorrect Password!" << endl;
    if(ack == "ALREADY LOGGED IN") cerr << "./client: User has already logged in!" << endl;
    if(ack == "LOGGED IN") cout << "User logged in successfully!" << endl;

    //cout << ack << endl;
}

//logout
void logout(int client_socket, vector<string> command_list) {
    if(command_list.size() > 1) {
        cerr << "./client: logout: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LOGOUT";
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);

    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "LOGGED OUT") cout << "User logged out successfully!" << endl;

    //cout << ack << endl;
}

//create_group
void create_group(int client_socket, vector<string> command_list) {
    if(command_list.size() < 2) {
        cerr << "./client: create_group: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 2) {
        cerr << "./client: create_group: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " CREATE_GROUP " + command_list[1];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP CREATED") cout << "Group created successfully!" << endl;
    if(ack == "GROUP EXISTS") cerr << "./client: Group already exists!" << endl;

    //cout << ack << endl;
}

//list_groups
void list_groups(int client_socket, vector<string> command_list) {
    if(command_list.size() > 1) {
        cerr << "./client: list_groups: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LIST_GROUPS";
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);

    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUPS LISTED") {
        cout << "Groups Listed!" << endl;
        string groups_list = "";
        read_from_tracker(client_socket, groups_list);
        cout << groups_list << endl;
    }

    //cout << ack << endl;
}

//leave_group
void leave_group(int client_socket, vector<string> command_list) {
    if(command_list.size() < 2) {
        cerr << "./client: leave_group: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 2) {
        cerr << "./client: leave_group: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LEAVE_GROUP " + command_list[1];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "REMOVED FROM GROUP") cout << "User removed from successfully!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User not in group!" << endl;

    //cout << ack << endl;
}

//join_group
void join_group(int client_socket, vector<string> command_list) {
    if(command_list.size() < 2) {
        cerr << "./client: join_group: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 2) {
        cerr << "./client: join_group: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " JOIN_GROUP " + command_list[1];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "JOIN REQUEST SENT") cout << "Join request sent!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "ALREADY IN GROUP") cerr << "./client: User already in group!" << endl;

    //cout << ack << endl;
}

//list_requests
void list_requests(int client_socket, vector<string> command_list) {
    if(command_list.size() < 2) {
        cerr << "./client: list_requests: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 2) {
        cerr << "./client: list_requests: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LIST_REQUESTS " + command_list[1];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;
    if(ack == "NOT GROUP OWNER") cerr << "./client: User is not group owner!" << endl;

    if(ack == "REQUESTS LISTED") {
        cout << "Requesters listed!" << endl;
        string requester_ids = "";
        read_from_tracker(client_socket, requester_ids);
        cout << requester_ids << endl;
    }

    //cout << ack << endl;
}

//accept_request
void accept_request(int client_socket, vector<string> command_list) {
    if(command_list.size() < 3) {
        cerr << "./client: accept_request: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 3) {
        cerr << "./client: accept_request: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " ACCEPT_REQUEST " + command_list[1] + " " + command_list[2];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;
    if(ack == "NOT GROUP OWNER") cerr << "./client: User is not group owner!" << endl;
    if(ack == "NOT REQUESTED") cerr << "./client: No such request was made!" << endl;

    if(ack == "REQUEST ACCEPTED") cout << "Request Accepted!" << endl;

    //cout << ack << endl;
}

//upload_file
void upload_file(int client_socket, vector<string> command_list) {
    if(command_list.size() < 3) {
        cerr << "./client: upload_file: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 3) {
        cerr << "./client: upload_file: Too many arguments!" << endl;
        return;
    }

    string file_path = command_list[1];
    long long file_size = file_size_of(file_path);
    if(file_size == -1) {
        cerr << "./client: upload_file: Invalid file path!" << endl;
        return;
    }

    string group_id = command_list[2];

    //Writing message to tracker
    string message = listening_socket + " UPLOAD_FILE " + command_list[1] + " " + command_list[2] + " " + to_string(file_size);
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;

    if(ack == "FILE UPLOADED") {
        cout << "File Uploaded!" << endl;

        //Setting the can_share flag for that particular file to be true for given group
        can_share[group_id][file_path] = true;
        if(can_share[group_id][file_path]) cout << "Can share file in the path " + file_path + " in group " + group_id << endl;

        //Storing the hashes for the file chunks for that particular file in the file_hash map
        file_hash[file_path] = get_all_hashes_for(file_path);

        //for(long long i = 0; i < file_hash[file_path].size(); i++) cout << "Hash[" << i << "]: " << file_hash[file_path][i] << endl;

        //Indicating that it has all file chunks for that file
        chunks_present[file_path] = vector<bool>(file_hash[file_path].size(), true);
    }

    //cout << ack << endl;
}

//list_files
void list_files(int client_socket, vector<string> command_list) {
    if(command_list.size() < 2) {
        cerr << "./client: list_files: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 2) {
        cerr << "./client: list_files: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " LIST_FILES " + command_list[1];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;

    if(ack == "FILES LISTED") {
        cout << "Files listed!" << endl;
        string file_names = "";
        read_from_tracker(client_socket, file_names);
        cout << file_names << endl;
    }

    //cout << ack << endl;
}

//download_file
void download_file(int client_socket, vector<string> command_list) {
    if(command_list.size() < 4) {
        cerr << "./client: download_file: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 4) {
        cerr << "./client: download_file: Too many arguments!" << endl;
        return;
    }

    string destination_path = command_list[3];
    string file_name = command_list[2];
    string group_id = command_list[1];

    //Writing message to tracker
    string message = listening_socket + " DOWNLOAD_FILE " + command_list[1] + " " + command_list[2] + " " + command_list[3];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;
    if(ack == "NO SUCH FILE") cerr << "./client: File not uploaded in group!" << endl;


    if(ack == "FILE DETAILS") {
        //cout << "File details provided!" << endl;

        //Getting file size from tracker
        string file_size_string = "";
        while(!read_from_tracker(client_socket, file_size_string));
        //cout << file_size_string << endl;
        long long file_size = stoll(file_size_string);

        //Getting file paths from tracker 
        string file_paths_for_file = "";
        while(!read_from_tracker(client_socket, file_paths_for_file));
        //cout << file_paths_for_file << endl;

        //Getting listening socket addresses for other clients
        string client_ports = "";
        while(!read_from_tracker(client_socket, client_ports));
        //cout << client_ports << endl;

        vector<string> other_client_listening_addresses = tokenize_commands(client_ports);
        vector<string> file_paths = tokenize_commands(file_paths_for_file);
        
        if(!create_download_file(file_name, destination_path, file_size)) {
            cerr << "./client: download_file: Invalid destination path!" << endl;
            return;
        }

        //Detaching a thread to download files from other clients
        thread file_downloader(start_downloading, group_id, file_name, destination_path, file_size, other_client_listening_addresses, file_paths);
        file_downloader.detach();


        //---------------------------More Code Yet To Come--------------------------------//
    }
}

//Function to start downloading the file in chunks
void start_downloading(string group_id, string file_name, string destination_path, long long file_size, vector<string> other_client_listening_addresses, vector<string> file_paths) {
    cout << "Started downloading " + file_name + " to destination path: " + destination_path << endl;
    string own_file_path;
    if(destination_path[destination_path.size() - 1] == '/')  own_file_path = destination_path + file_name;
    else own_file_path = destination_path + "/" + file_name;

    //0-index stores the seeder listening address (since it was the first client to upload the file)
    string seeder_listening_address = other_client_listening_addresses[0];
    string seeder_file_path = file_paths[0];


    //--------------------------Gettting File Hash from seeder-----------------------------//

    //Clearing the details of the file
    chunks_present[own_file_path].clear();
    chunk_freq[own_file_path].clear();
    file_hash[own_file_path].clear();

    //Querying seeder to obtain the hashes for the entire file in file_hashes
    string file_hash_list = "";
    int client_socket = create_client_socket(seeder_listening_address);

    string message = listening_socket + " HASH " + file_name + " " + seeder_file_path;
    write_to_other_client(client_socket, message);

    message = "";
    while(!read_from_other_client_casual(client_socket, message));

    vector<string> hash_for_file = tokenize_commands(message);
    for(long long i = 0; i < hash_for_file.size(); i++) {
        //cout << "Hash[" << i << "]: " << hash_for_file[i] << endl;
        file_hash[own_file_path].push_back(hash_for_file[i]);
        chunks_present[own_file_path].push_back(false);
        chunk_freq[own_file_path].push_back(0);
    }

    //Total no. of chunks in file
    int chunk_no = file_hash[own_file_path].size();

    //Closing the client_socket in order to reuse it
    close(client_socket);

    


    //---------Initializing the freq of each file chunk to zero in order to implement piece-selection algorithm (rarest piece first)----------//
    
    /*
    //No chunks for this particular file have been downloaded before
    if(chunks_present.find(own_file_path) == chunks_present.end()) {
        chunks_present[own_file_path] = vector<bool>(chunk_no, false);
        chunk_freq[own_file_path] = vector<int>(chunk_no, 0);
    }
    */
    
    //------------------------(Assuming entire file is always present in group)--------------------------------//
    //Looping while all the chunks of the file are not downloaded
    while(!all_true(chunks_present[own_file_path])) {

        //-------------------------------------PIECE SELECTION ALGORITHM---------------------------------------------------------//
        //Recalculating the chunk_freq for each chunk
        chunk_freq[own_file_path] = vector<int>(chunk_no, 0);

        //Making a map of which client has which chunk
        //key - chunk index,   value - client index vector
        map<long long, vector<long long>> clients_with_chunk;

        for(long long i = 0; i < other_client_listening_addresses.size(); i++) {
            client_socket = create_client_socket(other_client_listening_addresses[i]);

            message = listening_socket + " FREQ " + file_name + " " + file_paths[i];
            write_to_other_client(client_socket, message);

            message = "";
            while(!read_from_other_client_casual(client_socket, message));
            //cout << "Received freq from other clients: " << message << endl;

            for(long long j = 0; j < chunk_no; j++) {
                if(message[j] == '1') {
                    chunk_freq[own_file_path][i]++;
                    clients_with_chunk[j].push_back(i);
                }
            }

            close(client_socket);
        }

        long long chunk_to_download = -1;
        long long min_freq = chunk_no + 1;

        for(long long i = 0; i < chunk_no; i++) {
            //Take the chunk with minimum freq that is not already present
            if(!chunks_present[own_file_path][i] && chunk_freq[own_file_path][i] < min_freq) {
                chunk_to_download = i;
                min_freq = chunk_freq[own_file_path][i];
            }
        }

        //-------------------------------------------FILE CHUNK DOWNLOAD-------------------------------------------------------//

        //Selecting a random client with given chunk
        long long random_client_index_with_chunk = 0;

        while(true) {
            long long random_index = randomize(0, clients_with_chunk[chunk_to_download].size() - 1);
            random_client_index_with_chunk = clients_with_chunk[chunk_to_download][random_index];
            if(other_client_listening_addresses[random_client_index_with_chunk] != listening_socket) break;
        }

        /*
        //Selecting last recorded client with chunk (most recent)
        int last_client_with_chunk = clients_with_chunk[chunk_to_download][clients_with_chunk[chunk_to_download].size() - 1];

        client_socket = create_client_socket(other_client_listening_addresses[last_client_with_chunk]);
        */
        
        client_socket = create_client_socket(other_client_listening_addresses[random_client_index_with_chunk]);

        message = listening_socket + " DOWNLOAD " + file_name + " " + file_paths[random_client_index_with_chunk] + " " + to_string(chunk_to_download);
        write_to_other_client(client_socket, message);

        long long chunk_size;
        if(chunk_to_download == chunk_no - 1) {
            chunk_size = file_size % CHUNK_SIZE;
        }
        else {
            chunk_size = CHUNK_SIZE;
        }

        //cout << "Reading chunk " << chunk_to_download << " of size " << chunk_size << endl;
        
        message = "";
        while(!read_from_other_client(client_socket, chunk_size, message));

        string hash_for_chunk = calculate_SHA1_for(message.data(), message.size());

        //Checking if the SHA1 hash of file chunk matches the original SHA1 hash for that chunk
        if(hash_for_chunk != file_hash[own_file_path][chunk_to_download]) {
            cerr << "./client: download_file: Hash does not match for chunk" << chunk_to_download << endl;
        }
        else {
            write_chunk_to_file(own_file_path, message, chunk_to_download);
            chunks_present[own_file_path][chunk_to_download] = true;
        }
    }

    if(all_true(chunks_present[own_file_path])) {
        cout << "Download completed successfully!" << endl;
        string download_message = "C " + group_id + " " + file_name;
        downloaded_files.push_back(download_message);

        //for(int i = 0; i < downloaded_files.size(); i++) cout << downloaded_files[i] << endl;
    }
    else {
        cout << "Download failed!" << endl;
        string download_message = "D " + group_id + " " + file_name;
        downloaded_files.push_back(download_message);

        //for(int i = 0; i < downloaded_files.size(); i++) cout << downloaded_files[i] << endl;
    }
}

//Function to stop sharing a file
void stop_share(int client_socket, vector<string> command_list) {
    if(command_list.size() < 3) {
        cerr << "./client: stop_share: Too few arguments!" << endl;
        return;
    }
    if(command_list.size() > 3) {
        cerr << "./client: stop_share: Too many arguments!" << endl;
        return;
    }

    string group_id = command_list[1];
    string file_name = command_list[2];

    //Writing message to tracker
    string message = listening_socket + " STOP_SHARE " + command_list[1] + " " + command_list[2];
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);
    
    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "GROUP NOT EXISTS") cerr << "./client: Group does not exist!" << endl;
    if(ack == "NOT IN GROUP") cerr << "./client: User is not in group!" << endl;
    if(ack == "NO FILES IN GROUP") cerr << "./client: No files uploaded in group yet!" << endl;
    if(ack == "NO FILE") cerr << "./client: This file has not been uploaded in group!" << endl;
    if(ack == "HAS NOT SHARED") cerr << "./client: This file has not been uploaded/downloaded by this user in given group!" << endl;

    if(ack == "STOPPED SHARING") {
        cout << "Client has stopped sharing " << file_name << " group " << group_id << "!" << endl;
        can_share[group_id][file_name] = false;
    }
}

//Function to display all files that have been downloaded previously
void show_downloads(int client_socket, vector<string> command_list) {
    if(command_list.size() > 1) {
        cerr << "./client: show_downloads: Too many arguments!" << endl;
        return;
    }

    //Writing message to tracker
    string message = listening_socket + " SHOW_DOWNLOADS";
    write_to_tracker(client_socket, message);

    //Reading acknowledgement from tracker
    string ack = "";
    read_from_tracker(client_socket, ack);

    if(ack != "RECIEVED " + message) {
        cerr << "./client: Acknowledgement message not recieved!" << endl;
        close(client_socket);
        return;
    }

    //cout << ack << endl;

    //Reading success/failure of from tracker
    ack = "";
    while(!read_from_tracker(client_socket, ack));

    //Displaying appropriate message for success/failure
    if(ack == "NOT ASSIGNED") cerr << "./client: No user has been assigned yet!" << endl;
    if(ack == "NOT LOGGED IN") cerr << "./client: No user has logged in!" << endl;
    if(ack == "SHOW DOWNLOADS") {
        cout << "Showing downloads:" << endl;
        for(int i = 0; i < downloaded_files.size(); i++) cout << downloaded_files[i] << endl;
    }

    //cout << ack << endl;
}


