#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>
#include <random>

#include "client.h"

using namespace std;

//Function to get port from socket details
string get_port_from(string socket_details) {
    int colon_pos;
    if(socket_details.rfind(':') != string::npos) {
        colon_pos = socket_details.rfind(':');
        return socket_details.substr(colon_pos + 1);
    }
    else {
        cerr << "./client: Invalid socket address!" << endl;
        exit(1);
    }
}

//Function to get IP address from socket details
string get_IP_from(string socket_details) {
    int colon_pos;
    if(socket_details.rfind(':') != string::npos) {
        colon_pos = socket_details.rfind(':');
        return socket_details.substr(0, colon_pos);
    }
    else {
        cerr << "./client: Invalid socket address!" << endl;
        exit(1);
    }
}

//Function to read addresses of trackers from provided tracker_info file
vector<string> read_trackers(string tracker_info_file) {
    //Opening tracker_info file in read-only mode
    int tracker_info_fd = open(tracker_info_file.c_str(), O_RDONLY);

    //Checking if there is any error in opening the tracker_info_file
    if(tracker_info_fd == -1) {
        perror("tracker_info_file");
        exit(1);
    }

    vector<string> trackers;    //Vector to store the data for the 2 trackers
    string record = "";         //Stores data inside tracker_info_file
    char buffer[BUFFER_SIZE];
    while(true) {
        int bytes_r = read(tracker_info_fd, buffer, BUFFER_SIZE);

        //Error in reading from tracker_info_file
        if (bytes_r == -1) {
            perror("./client: tracker_info_file");
            close(tracker_info_fd);
            exit(1);
        }
        //End of file
        if (bytes_r == 0) break;

        //Stores the addresses of the trackers
        for (int i = 0; i < bytes_r; i++) {
            if (buffer[i] == '\n') {
                trackers.push_back(record);
                record.clear();
            } 
            else record += buffer[i];
        }
    }

    //If there's anything left in 'record', push it to 'trackers' (for the last line)
    if (!record.empty()) {
        trackers.push_back(record);
    }

    //Closing tracker_info_file
    close(tracker_info_fd);
    return trackers;
}

//Function to tokenize commands by whitespaces
vector<string> tokenize_commands(string commands) {
    if(commands.empty()) return {};   //Checks if string is empty
    vector<string> command_list;    //Stores all commands present in commands variable

    //Removing additonal ' ' from beginning of commands
    while(commands.at(0) == ' ') {
        commands = commands.substr(1);
    }

    //Tokenizing commands via ' '
    char* argument = strtok(commands.data(), " ");
    while(argument != NULL) {
        command_list.push_back(string(argument));
        argument = strtok(NULL, " ");
    }

    //Returning the string vector
    return command_list;
}

//Function to check if all values in a boolean vector are true
bool all_true(vector<bool>& vect) {
    for(int i = 0; i < vect.size(); i++) {
        if(!vect[i]) return false;
    }
    return true;
}

//Function to generate a random number in a certain range (start_val ... end_val)
long long randomize(long long start_val, long long end_val) {
    random_device randomizer;       //Obtaining random seed from hardware to initialize RNG
    mt19937 random_generator(randomizer());      //Inititalizing Mersenne Twister engine (64-bit) with obtained seed
    uniform_int_distribution<long long> random_distribution(start_val, end_val);    //Setting the range between which random numbers will be gnerated
    long long random_num = random_distribution(random_generator);       //Generating random number
    return random_num;
}