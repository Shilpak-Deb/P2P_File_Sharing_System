#ifndef CLIENT_HEADER
#define CLIENT_HEADER

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

using namespace std;

//Header file to access the various user-created Tracker functions commands

//----------------------------------------------------------------------------------------------------------------------------------//

//External Global Variables

extern string listening_socket;
extern int client_listener_socket;
extern map<string, map<string, bool>> can_share; 
extern map<string, vector<string>> file_hash;
extern map<string, vector<bool>> chunks_present;
extern map<string, vector<int>> chunk_freq;
extern mutex file_lock;
extern vector<string> downloaded_files;

//----------------------------------------------------------------------------------------------------------------------------------//

//Functions:

//misc.cpp
string get_port_from(string socket_details);
string get_IP_from(string socket_details);
vector<string> read_trackers(string tracker_info_file);
vector<string> tokenize_commands(string commands);
bool all_true(vector<bool>& vect);
long long randomize(long long start_val, long long end_val);

//fileop.cpp
long long file_size_of(string file_path);
string calculate_SHA1_for(char* file_chunk, int chunk_size);
vector<string> get_all_hashes_for(string file_path);
bool create_download_file(string file_name, string destination_path, long long file_size);
string read_chunk_from_file(string file_path, long long chunk_index);
bool write_chunk_to_file(string file_path, string file_chunk, long long chunk_index);

//comm.cpp
bool read_from_tracker(int client_socket, string& message);
bool write_to_tracker(int client_socket, string message);
int create_listener_socket();
void start_listening();
void talk_to_other_clients_as_server(int other_client_socket);
int create_client_socket(string other_client_listener_socket_address);
bool read_from_other_client_casual(int client_socket, string& message);
bool read_from_other_client(int client_socket, long long chunk_size, string& message);
bool write_to_other_client(int client_socket, string message);

//commands.cpp
void create_user(int client_socket, vector<string> command_list);
void login(int client_socket, vector<string> command_list);
void logout(int client_socket, vector<string> command_list);
void create_group(int client_socket, vector<string> command_list);
void list_groups(int client_socket, vector<string> command_list);
void leave_group(int client_socket, vector<string> command_list);
void join_group(int client_socket, vector<string> command_list);
void list_requests(int client_socket, vector<string> command_list);
void accept_request(int client_socket, vector<string> command_list);
void upload_file(int client_socket, vector<string> command_list);
void list_files(int client_socket, vector<string> command_list);
void download_file(int client_socket, vector<string> command_list);
void start_downloading(string group_id, string file_name, string destination_path, long long file_size, vector<string> other_client_listening_addresses, vector<string> file_paths);
void stop_share(int client_socket, vector<string> command_list);
void show_downloads(int client_socket, vector<string> command_list);

//----------------------------------------------------------------------------------------------------------------------------------//

#endif