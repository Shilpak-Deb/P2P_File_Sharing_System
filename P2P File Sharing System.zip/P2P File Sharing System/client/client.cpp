#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "client.h"

using namespace std;

string listening_socket;                     //Global variable to store listening socket address
int client_listener_socket;                  //Global variable to store the fd of client's listener socket to listen to other clients
map<string, map<string, bool>> can_share;    //Global nested map to check if a particular file in a particular group can be shared
map<string, vector<string>> file_hash;       //Global map to store the vector of SHA1 hashes for the chunks of the file (key value = file_path) (for upload)
map<string, vector<bool>> chunks_present;    //Global map to keep track of which chunks for a file are present with client (key value = file path) (for both upload & downloads)
map<string, vector<int>> chunk_freq;         //GLobal map to store the freq. of each file chunk in group for a file and for this particular client (for download)
mutex file_lock;                             //Global mutex to protect global data structures during modification
vector<string> downloaded_files;             //Global vector to keep track of all files previously downloaded

//----------------------------------------------------------------------------------------------------------------------------------//

//Function to communicate with tracker
void talk_to_tracker(vector<string> trackers, string input) {

    //----------------------------------------------------------------------------------------------------------------------------------//

    int client_socket = socket(AF_INET, SOCK_STREAM, 0);    //Creating a client socket to communicate with tracker
    //Checking if socket was created successfully
    if(client_socket == -1) {
        perror("./client: Client socket creation failed");
        exit(1);
    }

    //Setting socket option to allow reuse
    int opt = 1;
    if (setsockopt(client_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
        perror("./client: setsockopt() failed");
        close(client_socket);
        exit(1);
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    bool both_trackers_down = true;     //Keeps track of if both trackers are down

    //Checks both trackers in order
    for(int i = 0; i < 2; i++) {

        //----------------------------------------------------------------------------------------------------------------------------------//

        int tracker_port = stoi(get_port_from(trackers[i]));
        string tracker_IP = get_IP_from(trackers[i]);

        cout << "Connecting to tracker at IP: " << tracker_IP << " Port: " << tracker_port << endl;

        //Storing address of tracker
        sockaddr_in tracker_addr = {};
        tracker_addr.sin_family = AF_INET;                       //IPv4 addressing
        tracker_addr.sin_port = htons(tracker_port);      //Assigns port no. for server to listen from

        //Assigns address of default tracker to tracker_addr
        if (inet_pton(AF_INET, tracker_IP.c_str(), &tracker_addr.sin_addr) <= 0) {
            perror("./client: Invalid address");
            close(client_socket);
            exit(1);
        }

        //----------------------------------------------------------------------------------------------------------------------------------//

        //Checking if connection can be done
        int can_connect = connect(client_socket, (struct sockaddr *)&tracker_addr, sizeof(tracker_addr));
        if (can_connect == -1) {
            perror("./client: Failed to connect to tracker");
            continue;
        }
        else {
            both_trackers_down = false;
            break;
        }     

        //----------------------------------------------------------------------------------------------------------------------------------//

    }

    //Checking if both trackers are down
    if(both_trackers_down) {
        cerr << "./client: Both trackers down!" << endl;
        close(client_socket);
        exit(1);
    }

    //----------------------------------------------------------------------------------------------------------------------------------//
    
    vector<string> command_list = tokenize_commands(input);  //Tokenizing client input
    if(command_list.empty()) {
        cerr << "./client: Invalid command!" << endl;
        return;
    }
        
    string command = command_list[0];   //Stores which command has been sent by user
    string message = "";                //Stores message to be sent to tracker

    //-----------------------------------------------< COMMANDS >-----------------------------------------------------------------------//
    
    if(command == "create_user") create_user(client_socket, command_list);                  //create_user
    else if(command == "login") login(client_socket, command_list);                         //login
    else if(command == "logout") logout(client_socket, command_list);                       //logout
    else if(command == "create_group") create_group(client_socket, command_list);           //create_group
    else if(command == "list_groups") list_groups(client_socket, command_list);             //list_groups
    else if(command == "leave_group") leave_group(client_socket, command_list);             //leave_group
    else if(command == "join_group") join_group(client_socket, command_list);               //join_group
    else if(command == "list_requests") list_requests(client_socket, command_list);         //list_requests
    else if(command == "accept_request") accept_request(client_socket, command_list);       //accept_request
    else if(command == "upload_file") upload_file(client_socket, command_list);             //upload_file
    else if(command == "list_files") list_files(client_socket, command_list);               //list_files
    else if(command == "download_file") download_file(client_socket, command_list);         //download_file
    else if(command == "stop_share") stop_share(client_socket, command_list);               //stop_share
    else if(command == "show_downloads") show_downloads(client_socket, command_list);       //show_downloads

    //----------------------------------------------------------------------------------------------------------------------------------//

    //Invalid commands
    else {
        cerr << "./client: Invalid command" << endl;
        return;
    }

    //----------------------------------------------------------------------------------------------------------------------------------//
    
    if(shutdown(client_socket, SHUT_RDWR) == -1) {
        perror("./client: Cannot terminate connection with server");
        exit(1);
    }
    if(close(client_socket) == -1) {
        perror("./client: Cannot close client socket");
        exit(1);
    }

    //----------------------------------------------------------------------------------------------------------------------------------//
}

//----------------------------------------------------------------------------------------------------------------------------------//

//Main function
int main(int argcount, char* arguments[]) {
    //----------------------------------------------------------------------------------------------------------------------------------//

    //Checking if the no.of arguments provided are valid
    if(argcount < 3) {
        cerr << "./client: Too few arguments!" << endl;
        return -1;
    }
    else if(argcount > 3) {
        cerr << "./client: Too many arguments!" << endl;
        return -1;
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    listening_socket = arguments[1];                            //Stores the socket address for client to operate from
    client_listener_socket = create_listener_socket();          //Creates a listener socket for client to listen from
    //Creating a new thread to listen to other clients
    thread listen_to_other_clients(start_listening);
    listen_to_other_clients.detach();

    //----------------------------------------------------------------------------------------------------------------------------------//

    string tracker_info_file = arguments[2];        //Stores tracker_info file to open trackers
    vector<string> trackers = read_trackers(tracker_info_file);     //Reads addresses of trackers from tracker_info_file

    //Checking if no. of trackers present in tracker_info_file are valid
    if(trackers.size() < 2) {
        cerr << "./client: Too few tracker addresses!" << endl;
        return -1;
    }

    //----------------------------------------------------------------------------------------------------------------------------------//
    
    //Infinite loop to accept data from user
    while(true) {

        //----------------------------------------------------------------------------------------------------------------------------------//

        string client_input;            //Taking input from user
        getline(cin, client_input);

        talk_to_tracker(trackers, client_input);    //Handling client input

        //----------------------------------------------------------------------------------------------------------------------------------//
    }


}