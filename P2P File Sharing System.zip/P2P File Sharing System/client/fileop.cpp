#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "client.h"

using namespace std;

//Function to find the size of a file based on filepath provided
long long file_size_of(string file_path) {
    struct stat file_stat;

    if (stat(file_path.c_str(), &file_stat) == -1) {
        perror("./client: Error in calculating file size");
        return -1;
    }

    return file_stat.st_size;
}

//Function to get SHA1 for a file chunk (in C++ string format)
string calculate_SHA1_for(char* file_chunk, int chunk_size) {
    //Edge case handling
    if (chunk_size <= 0) return "";

    unsigned char sha1_hash[SHA_DIGEST_LENGTH];     //char array to store SHA1 hash (20 bytes)

    //Calculating the SHA1 hash for given chunk
    SHA_CTX ctx;                                    //Initializes a context structure (part of OPENSSL library)
    SHA1_Init(&ctx);                                //Initializes the context
    SHA1_Update(&ctx, file_chunk, chunk_size);      //Processes the file chunk
    SHA1_Final(sha1_hash, &ctx);                    //Finalizes the computation and stores the hash in sha1_hash

    //Converting result to C++ string for ease of use
    string hash_string;

    char buffer[3];  //Buffer to hold 2 hex characters + null terminator

    for (int i = 0; i < SHA_DIGEST_LENGTH; ++i) {
        snprintf(buffer, sizeof(buffer), "%02x", sha1_hash[i]);     //Converting into a 2-character hexadecimal string
        hash_string += buffer;                                      //Appending to hash_string
    }

    return hash_string;
}

//Function to return a vector of all SHA1 hashes for all chunks of the file
vector<string> get_all_hashes_for(string file_path) {
    //Opening file in read-only mode
    int fd = open(file_path.c_str(), O_RDONLY);

    //Checking if file_path is valid
    if(fd == -1) {
        perror("./client: SHA1: Error in opening file");
        return {};
    }

    char buffer[CHUNK_SIZE ];       //Buffer to read chunks from file
    int bytes_r;                    //Stores the no. of bytes read via read() system call
    vector<string> chunk_hashes;    //Stores the hashes for each chunk of file

    //Loop runs till there are contents of the file yet to read or if it encounters an error
    while((bytes_r = read(fd, buffer, CHUNK_SIZE)) > 0) {
        string hash = calculate_SHA1_for(buffer, bytes_r);
        chunk_hashes.push_back(hash);
    }

    //Error handling
    if(bytes_r == -1) {
        perror("./client: SHA1: Error in reading from file");
        close(fd);
        return {};
    }

    close(fd);
    return chunk_hashes;
}

//Function to create a file based on destination_path and file_name provided
bool create_download_file(string file_name, string destination_path, long long file_size) {
    string file_path;
    if(destination_path[destination_path.size() - 1] == '/')  file_path = destination_path + file_name;
    else file_path = destination_path + "/" + file_name;

    int download_fd = open(file_path.c_str(), O_CREAT | O_WRONLY | O_TRUNC, 0600);
    if(download_fd == -1) {
        return false;
    }

    //Fill file with zeroes (upto file size)
    char buffer[1];
    buffer[0] = '0';

    for(long long i = 0; i < file_size; i++) write(download_fd, buffer, 1);

    //Closing the download file descriptor
    close(download_fd);

    return true;
}

//Function to read a particular chunk from a file
string read_chunk_from_file(string file_path, long long chunk_index) {
    //Opening file in read-only mode
    int fd = open(file_path.c_str(), O_RDONLY);

    //Checking if file_path is valid
    if(fd == -1) {
        perror("./client: Error in opening file");
        return "";
    }

    //Checking if chunk_index is valid
    if(lseek(fd, CHUNK_SIZE * chunk_index, SEEK_SET) == -1) {
        perror("./client: Error in setting start position according to chunk_index");
        close(fd);
        return "";
    }

    char buffer[CHUNK_SIZE];                             //Buffer to read chunks from file
    int bytes_r = read(fd, buffer, CHUNK_SIZE);          //Stores the no. of bytes read via read() system call

    if(bytes_r == -1) {
        perror("./client: Error in reading from file");
        close(fd);
        return "";
    }

    string file_chunk(buffer, bytes_r);

    close(fd);

    return file_chunk;
}

//Function to write a particular chunk to a file
bool write_chunk_to_file(string file_path, string file_chunk, long long chunk_index) {
    //Opening file in write-only mode (with append to not overwrite previous file)
    int fd = open(file_path.c_str(), O_WRONLY);

    //Checking if file_path is valid
    if(fd == -1) {
        perror("./client: Error in opening file");
        return false;
    }

    //Checking if chunk_index is valid
    if(lseek(fd, CHUNK_SIZE * chunk_index, SEEK_SET) == -1) {
        perror("./client: Error in setting start position according to chunk_index");
        close(fd);
        return false;
    }

    //Checking if write() can be done
    if(write(fd, file_chunk.c_str(), file_chunk.size()) == -1) {
        perror("./client: Error in writing to file");
        close(fd);
        return false;
    }

    close(fd);
    
    return true;
}