#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "tracker.h"

using namespace std;

//----------------------------------------------------------------------------------------------------------------------------------//

atomic<bool> is_running(false);     //Global atomic variable to check if the tracker is running

mutex client_lock;                                  //Global variable to protect the set of client sockets while concurrently running multiple server threads
map<string, vector<User>> groups;                   //Global variable to keep track of different groups by mapping them to a string Group ID 
vector<User> users;                                 //Keeps track of registered user(s) for the tracker
map<string, vector<string>> join_requests;          //Keeps track of all join requests (key value is user ID of owner)
map<string, vector<File_Details>> files_in_group;   //Keeps track of all uploaded files in group (key value is group ID)

//----------------------------------------------------------------------------------------------------------------------------------//

//Function to implement quit command
void quit_command() {
    string quit_input;
    while(is_running) {
        cin >> quit_input;
        if(quit_input == "quit") {
            is_running = false;
        }
    }
    exit(0);
}

//----------------------------------------------------------------------------------------------------------------------------------//

//Function to communicate with client
void talk_to_client(int client_socket) {

    char buffer[BUFFER_SIZE];      //Creating a char (byte) buffer to store incoming data from client_socket

    //Infinite loop to communicate with client
    while(true) {

        //----------------------------------------------------------------------------------------------------------------------------------//
        
        int bytes_r = read(client_socket, buffer, BUFFER_SIZE);    //Keeps track of no. of bytes read from client socket

        //Client socket has disconnected
        if (bytes_r == -1 || bytes_r == 0) break;

        //----------------------------------------------------------------------------------------------------------------------------------//
        
        //Sending an acknowledgement message to client
        string ack = "RECIEVED ";
        for(int i = 0; i < bytes_r; i++) ack += buffer[i];
        write(client_socket, ack.c_str(), ack.size());

        //----------------------------------------------------------------------------------------------------------------------------------//

        string message = "";    //Stores the commands provided by the client socket
        for(int i = 0; i < bytes_r; i++) message += buffer[i];
        vector<string> command_list = tokenize_commands(message);      //Storing all commands in a string vector


        //---------------------------ERROR CHECK----------------------------------//
        for(int i = 0; i < command_list.size(); i++) {
            cout << command_list[i] << " ";
        }
        cout << endl;
        //---------------------------ERROR CHECK----------------------------------//



        //Checking if command_list is empty or only has client listening socket address
        if(command_list.empty() || command_list.size() == 1) return;
 
        //Checking which commands have been provided to tracker
        //command_list[1] refers to which command has been entered
        //FORMAT of MESSAGE:     <listening_socket> <command> arg1 arg2 ... 
        string command = command_list[1];

        //----------------------------------------------------< COMMANDS >------------------------------------------------------------------//

        if(command == "CREATE_USER") create_user(client_socket, command_list);
        else if(command == "LOGIN") login(client_socket, command_list);
        else if(command == "LOGOUT") logout(client_socket, command_list);
        else if(command == "CREATE_GROUP") create_group(client_socket, command_list);
        else if(command == "LIST_GROUPS") list_groups(client_socket, command_list);
        else if(command == "LEAVE_GROUP") leave_group(client_socket, command_list);
        else if(command == "JOIN_GROUP") join_group(client_socket, command_list);
        else if(command == "LIST_REQUESTS") list_requests(client_socket, command_list);
        else if(command == "ACCEPT_REQUEST") accept_request(client_socket, command_list);
        else if(command == "UPLOAD_FILE") upload_file(client_socket, command_list);
        else if(command == "LIST_FILES") list_files(client_socket, command_list);
        else if(command == "DOWNLOAD_FILE") download_file(client_socket, command_list);
        else if(command == "STOP_SHARE") stop_share(client_socket, command_list);
        else if(command == "SHOW_DOWNLOADS") show_downloads(client_socket, command_list);
        
        //----------------------------------------------------------------------------------------------------------------------------------//

        //Condition to check for default condition
        else {
            //---------------DEFAULT CODE (if required)---------------//
        }
    }

    close(client_socket);
}

//----------------------------------------------------------------------------------------------------------------------------------//

//Main function
int main(int argcount, char* arguments[]) {

    //----------------------------------------------------------------------------------------------------------------------------------//

    //Checking if the no.of arguments provided are valid
    if(argcount < 3) {
        cerr << "./tracker: Too few arguments!" << endl;
        return -1;
    }
    else if(argcount > 3) {
        cerr << "./tracker: Too many arguments!" << endl;
        return -1;
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    string tracker_info_file = arguments[1];    //Stores tracker_info file to open trackers
    vector<string> trackers = read_trackers(tracker_info_file);     //Reads addresses of trackers from tracker_info_file
    
    //Checking if no. of trackers present in tracker_info_file are valid
    if(trackers.size() < 2) {
        cerr << "./tracker: Too few tracker addresses!" << endl;
        return -1;
    }
    else if(trackers.size() > 2) {
        cerr << "./tracker: Too many tracker addresses - only the first 2 will be utilized!" << endl;
    }

    int tracker_no = stoi(arguments[2]);    //Stores tracker no. that needs to be run

    //Checking if the tracker no. provided is valid
    if(tracker_no < 1 || tracker_no > 2) {
        cerr << "./tracker: Invalid tracker no." << endl;
        return -1;
    }

    int tracker_listening_port = stoi(get_port_from(trackers[tracker_no - 1]));   //Stores the port address of the current tracker
    string tracker_ip = get_IP_from(trackers[tracker_no - 1]);                    //Stores the IP address of the current tracker

    //----------------------------------------------------------------------------------------------------------------------------------//

    //sync_with_other_tracker(tracker_no);

    //----------------------------------------------------------------------------------------------------------------------------------//

    int server_socket = socket(AF_INET, SOCK_STREAM, 0);    //Creating server socket (TCP)
    //Checking if server socket has been created successfully
    if (server_socket == -1) {
        perror("./tracker: Server socket creation failed");
        return -1;
    }

    //Storing address of server
    sockaddr_in server_address;
    server_address.sin_family = AF_INET;                                //IPv4 addressing
    inet_pton(AF_INET, tracker_ip.c_str(), &server_address.sin_addr);   //Assigns IP address for server to listen from
    server_address.sin_port = htons(tracker_listening_port);            //Assigns port no. for server to listen from

    //Associates socket with server address and port
    if(bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1) {
        perror("./tracker: Bind failed for server socket");
        close(server_socket);
        return -1;
    }

    //Places server in passive listening state to accept incoming connections
    if (listen(server_socket, BACKLOG) == -1) {
        perror("./tracker: Listen failed for server socket");
        close(server_socket);
        return -1;
    }

    cout << "Tracker " << tracker_no << " is listening on " << trackers[tracker_no - 1] << endl;

    //----------------------------------------------------------------------------------------------------------------------------------//

    is_running = true;  //Sets is_running as true

    //Checks if quit command has been entered
    thread quit_check(quit_command);
    quit_check.detach();

    //----------------------------------------------------------------------------------------------------------------------------------//

    //Set timeout so that it can repeatedly check for new connections by going to the next iteration of the loop
    struct timeval timeout;
    timeout.tv_sec = 5;  //5 seconds
    timeout.tv_usec = 0;  //0 microseconds

    //Setting socket option so that socket can repeatedly check for new connections
    setsockopt(server_socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));

    //----------------------------------------------------------------------------------------------------------------------------------//

    while(is_running) {
        int client_socket = accept(server_socket, NULL, NULL);
        //Error checking for if accept() operation fails
        if(client_socket < 0) {
            if(errno == EWOULDBLOCK || errno == EAGAIN) continue;
            else perror("./tracker: Client socket creation failed");
            continue;
        } 

        //Spawn a new thread to handle the client
        thread client_thread(talk_to_client, client_socket);
        client_thread.detach();  //Detach client thread to allow for independent handling
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    close(server_socket);   //Close the server socket
    return 0;
}
