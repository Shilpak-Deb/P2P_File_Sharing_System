#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "tracker.h"

using namespace std;

//CREATE_USER
void create_user(int client_socket, vector<string> command_list) {
    //Creating an User variable to store details of user provided
    User usr;
    usr.user_id = command_list[2];
    usr.password = command_list[3];
    usr.listening_IP = get_IP_from(command_list[0]);
    usr.listening_port = stoi(get_port_from(command_list[0]));
    usr.logged_in = false;

    {
        lock_guard<mutex> lock(client_lock);    ///Prevents multiple concurrent threads from changing stored data structures
        //Checks a different user is already present for this device
        if(search_by_address(users, usr.listening_IP, usr.listening_port) == -1) {
            //Checks if user is already registered
            if(search_by_id(users, usr.user_id) == -1) {
                users.push_back(usr);              //Storing new user

                cout << "Successfully updated user vector" << endl;
                string success_msg = "USER ADDED";
                write(client_socket, success_msg.c_str(), success_msg.size()); 
            }
            else {
                cerr << "./tracker: User exists!" << endl;
                string error_msg = "USER EXISTS";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
        }
        else {
            cerr << "./tracker: Multiple users cannot be created from same client!" << endl;
            string error_msg = "MULTIPLE USERS";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
    }
}

//LOGIN
void login(int client_socket, vector<string> command_list) {
    string user_id = command_list[2];
    string password = command_list[3];
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        //Checks if user is already registered
        if(search_by_id(users, user_id) == -1) {
            cerr << "./tracker: User does not exist!" << endl;
            string error_msg = "USER NOT EXISTS";
            write(client_socket, error_msg.c_str(), error_msg.size());          
        }
        else {
            int match = search_by_id(users, user_id);
            if(users[match].listening_IP == listening_IP && users[match].listening_port == listening_port) {
                if(users[match].password == password) {
                    if(users[match].logged_in) {
                        cerr << "./tracker: User has already logged in!" << endl;
                        string error_msg = "ALREADY LOGGED IN";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        users[match].logged_in = true;
                        cout << "User logged in successfully!" << endl;
                        string success_msg = "LOGGED IN";
                        write(client_socket, success_msg.c_str(), success_msg.size()); 
                    }
                }
                else {
                    cerr << "./tracker: Invalid credentials!" << endl;
                    string error_msg = "WRONG PASSWORD";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
            }
            else {
                cerr << "./tracker: Invalid credentials!" << endl;
                string error_msg = "INVALID CREDENTIALS";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
        }            
    }
}

//LOGOUT
void logout(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);

        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                users[match].logged_in = false;
                cout << "User logged out successfully!" << endl;
                string success_msg = "LOGGED OUT";
                write(client_socket, success_msg.c_str(), success_msg.size());
            }
        }
    }
}

//CREATE_GROUP
void create_group(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);

        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present - Creating Group
                if(groups.find(group_id) == groups.end()) {
                    groups[group_id] = vector<User>();
                    groups[group_id].push_back(users[match]);

                    cout << "Group created successfully!" << endl;
                    string success_msg = "GROUP CREATED";
                    write(client_socket, success_msg.c_str(), success_msg.size());
                }
                //Groups already exists
                else {
                    cerr << "./tracker: Group already exists!" << endl;
                    string error_msg = "GROUP EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
            }
        }
    } 
}

//LIST_GROUPS
void list_groups(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);

        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                cout << "Groups Listed!" << endl;
                string success_msg = "GROUPS LISTED";
                write(client_socket, success_msg.c_str(), success_msg.size());
                usleep(200);

                string group_list = "";
                for (const auto& group : groups) {
                    group_list += group.first + ", ";
                }
                write(client_socket, group_list.c_str(), group_list.size());
            }
        }
    }
}

//LEAVE_GROUP
void leave_group(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);

        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        //User is group owner - delete group
                        if(group_match == 0) {
                            auto it = groups.find(group_id);
                            groups.erase(it);
                        }
                        //Delete only user
                        else {
                            groups[group_id].erase(groups[group_id].begin() + group_match); 
                        }
                        cout << "User removed from group!" << endl;
                        string success_msg = "REMOVED FROM GROUP";
                        write(client_socket, success_msg.c_str(), success_msg.size());
                    }
                }
            }
       }
    }
}

//JOIN_GROUP
void join_group(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        string request = listening_IP + " " + to_string(listening_port) + " " + group_id; 

                        //join requests are not present for particular group owner yet
                        //groups[group_id][0] --> owner of group with group_id as ID
                        if(join_requests.find(groups[group_id][0].user_id) == join_requests.end()) {
                            join_requests[groups[group_id][0].user_id] = vector<string>();
                            join_requests[groups[group_id][0].user_id].push_back(request);
                        }
                        //join requests are already present for particular group owner
                        else {
                            join_requests[groups[group_id][0].user_id].push_back(request);
                        }

                        cout << "Join request sent!" << endl;
                        string success_msg = "JOIN REQUEST SENT";
                        write(client_socket, success_msg.c_str(), success_msg.size());
                    }
                    //User is in group
                    else {
                        cerr << "./tracker: User already in group!" << endl;
                        string error_msg = "ALREADY IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                }
            }
        }
    }
}

//LIST_REQUESTS
void list_requests(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        //User is in group but not the owner
                        if(group_match != 0) {
                            cerr << "./tracker: User is not group owner!" << endl;
                            string error_msg = "NOT GROUP OWNER";
                            write(client_socket, error_msg.c_str(), error_msg.size());
                        }
                        //User is group owner
                        else {
                            User owner = groups[group_id][0];
                            vector<string> requesters = search_requests_by(join_requests[owner.user_id], group_id);

                            string requester_ids = "";

                            for(int i = 0; i < requesters.size(); i++) {
                                vector<string> req_list = tokenize_commands(requesters[i]);
                                string req_IP = req_list[0];
                                int req_port = stoi(req_list[1]);
                                        
                                int req_match = search_by_address(users, req_IP, req_port);
                                requester_ids += users[req_match].user_id + ", ";
                            }

                            cout << "Requesters Listed!" << endl;
                            string success_msg = "REQUESTS LISTED";
                            write(client_socket, success_msg.c_str(), success_msg.size());
                            usleep(200);

                            write(client_socket, requester_ids.c_str(), requester_ids.size());
                        }
                    }
                }
            }
        }
    }
}

//ACCEPT_REQUEST
void accept_request(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];
    string req_user_id = command_list[3];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        //User is in group but not the owner
                        if(group_match != 0) {
                            cerr << "./tracker: User is not group owner!" << endl;
                            string error_msg = "NOT GROUP OWNER";
                            write(client_socket, error_msg.c_str(), error_msg.size());
                        }
                        //User is group owner
                        else {
                            User owner = groups[group_id][0];
                            vector<string> requesters = search_requests_by(join_requests[owner.user_id], group_id);

                            bool did_request = false;
                            int req_index = -1;

                            for(int i = 0; i < requesters.size(); i++) {
                                vector<string> req_list = tokenize_commands(requesters[i]);
                                string req_IP = req_list[0];
                                int req_port = stoi(req_list[1]);
                                        
                                int req_match = search_by_address(users, req_IP, req_port);
                                if(req_user_id == users[req_match].user_id) {
                                    did_request = true;
                                    req_index = i;
                                    break;
                                }
                            }

                            //Made a request
                            if(did_request) {
                                int match_user = search_by_id(users, req_user_id);
                                groups[group_id].push_back(users[match_user]);
                                join_requests[owner.user_id].erase(join_requests[owner.user_id].begin() + req_index);

                                cout << "Request Accepted!" << endl;
                                string success_msg = "REQUEST ACCEPTED";
                                write(client_socket, success_msg.c_str(), success_msg.size());
                            }
                            //Did not make a request
                            else {
                                cerr << "./tracker: No such request was made!" << endl;
                                string error_msg = "NOT REQUESTED";
                                write(client_socket, error_msg.c_str(), error_msg.size());
                            }
                        }
                    }
                }
            }
        }
    }
}

//UPLOAD_FILE
void upload_file(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[3];
    string file_path = command_list[2];
    string file_name = get_filename_from(file_path);
    long long file_size = stoll(command_list[4]);

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        //No entry for the group has been created yet
                        if(files_in_group.find(group_id) == files_in_group.end()) {
                            File_Details newfile;
                            newfile.file_name = file_name;
                            newfile.file_paths.push_back(file_path);
                            newfile.file_size = file_size;
                            newfile.user_ids.push_back(users[match].user_id);

                            files_in_group[group_id] = vector<File_Details>();
                            files_in_group[group_id].push_back(newfile);

                            cout << "File Uploaded (First file uploaded to group)!" << endl;
                            string success_msg = "FILE UPLOADED";
                            write(client_socket, success_msg.c_str(), success_msg.size());
                        }
                        else {
                            int file_match = search_by_filename(files_in_group[group_id], file_name);

                            //File has not been previously uploaded
                            if(file_match == -1) {
                                File_Details newfile;
                                newfile.file_name = file_name;
                                newfile.file_paths.push_back(file_path);
                                newfile.file_size = file_size;
                                newfile.user_ids.push_back(users[match].user_id);

                                //files_in_group[group_id] = vector<File_Details>();
                                files_in_group[group_id].push_back(newfile);

                                cout << "File Uploaded!" << endl;
                                string success_msg = "FILE UPLOADED";
                                write(client_socket, success_msg.c_str(), success_msg.size());                            
                            }
                            //File has been previously uploaded
                            else {
                                //Assuming that each file uploaded has a unique name
                                int file_uploaded_match = search_by_string(files_in_group[group_id][file_match].user_ids, users[match].user_id);

                                //File had not been uploaded/downloaded by this user before
                                if(file_uploaded_match == -1) {
                                    files_in_group[group_id][file_match].user_ids.push_back(users[match].user_id);
                                    files_in_group[group_id][file_match].file_paths.push_back(file_path);

                                    cout << "File Uploaded (not uploaded/downloaded by this user before)!" << endl;
                                    string success_msg = "FILE UPLOADED";
                                    write(client_socket, success_msg.c_str(), success_msg.size());   
                                }
                                //File has been uploaded/downloaded by this user before
                                else {
                                    //Updating file path ONLY (since then rest match)
                                    files_in_group[group_id][file_match].file_paths[file_uploaded_match] = file_path;

                                    cout << "File Uploaded (previously uploaded/downloaded by this user - updating file path ONLY)!" << endl;
                                    string success_msg = "FILE UPLOADED";
                                    write(client_socket, success_msg.c_str(), success_msg.size());
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

//LIST_FILES
void list_files(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        string file_names_in_group = "";

                        for(int i = 0; i < files_in_group[group_id].size(); i++) {
                            file_names_in_group += files_in_group[group_id][i].file_name + ", "; 
                        }

                        cout << "Files Listed!" << endl;
                        string success_msg = "FILES LISTED";
                        write(client_socket, success_msg.c_str(), success_msg.size());
                        usleep(200);

                        write(client_socket, file_names_in_group.c_str(), file_names_in_group.size());
                    }
                }
            }
        }
    }
}

//DOWNLOAD_FILE
void download_file(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];
    string file_name = command_list[3];
    string destination_path = command_list[4];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        int file_match = search_by_filename(files_in_group[group_id], file_name);
                        //File not present in group
                        if(file_match == -1) {
                            cerr << "./tracker: File not uploaded in group!" << endl;
                            string error_msg = "NO SUCH FILE";
                            write(client_socket, error_msg.c_str(), error_msg.size());
                        }
                        //File present in group
                        else {
                            string file_size_for_file = to_string(files_in_group[group_id][file_match].file_size);
                            string file_paths_for_file = "";
                            string listening_sockets_for_file = "";

                            //cout << "Reaches here i.e. file present in group" << endl;

                            for(int i = 0; i < files_in_group[group_id][file_match].file_paths.size(); i++) {
                                file_paths_for_file += files_in_group[group_id][file_match].file_paths[i] + " "; 

                                int file_index = search_by_id(users, files_in_group[group_id][file_match].user_ids[i]);
                                listening_sockets_for_file += users[file_index].listening_IP + ":" + to_string(users[file_index].listening_port) + " ";
                            }
                            
                            //Updating the file details with the new file provided

                            int file_uploaded_match = search_by_string(files_in_group[group_id][file_match].user_ids, users[match].user_id);

                            //cout << "Reaches here i.e. file_uploaded_match was calculated" << endl;

                            //File had not been downloaded by user previously
                            if(file_uploaded_match == -1) {
                                files_in_group[group_id][file_match].file_paths.push_back(get_filepath_from(destination_path, file_name));
                                files_in_group[group_id][file_match].user_ids.push_back(users[match].user_id);
                                cout << "File details for " + file_name + " added to group " + group_id + "!" << endl;
                            }
                            //File had been already downloaded by user previously
                            else {
                                files_in_group[group_id][file_match].file_paths[file_uploaded_match] = get_filepath_from(destination_path, file_name);
                                cout << "File details for " + file_name + " updated in group " + group_id + "!" << endl;
                            }

                            cout << "File details provided to client!" << endl;
                            string success_msg = "FILE DETAILS";
                            write(client_socket, success_msg.c_str(), success_msg.size());
                            usleep(200);

                            write(client_socket, file_size_for_file.c_str(), file_size_for_file.size());
                            usleep(200);
                            write(client_socket, file_paths_for_file.c_str(), file_paths_for_file.size());
                            usleep(200);
                            write(client_socket, listening_sockets_for_file.c_str(), listening_sockets_for_file.size());
                        }
                    }
                }
            }
        }
    }
}

//STOP_SHARE
void stop_share(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));
    string group_id = command_list[2];
    string file_name = command_list[3];

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);
        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                //Group not present
                if(groups.find(group_id) == groups.end()) {
                    cerr << "./tracker: Group does not exist!" << endl;
                    string error_msg = "GROUP NOT EXISTS";
                    write(client_socket, error_msg.c_str(), error_msg.size());
                }
                else {
                    int group_match = search_by_id(groups[group_id], users[match].user_id);

                    //User is not in group
                    if(group_match == -1) {
                        cerr << "./tracker: User not in group!" << endl;
                        string error_msg = "NOT IN GROUP";
                        write(client_socket, error_msg.c_str(), error_msg.size());
                    }
                    else {
                        //No entry for the group has been created yet
                        if(files_in_group.find(group_id) == files_in_group.end()) {
                            cerr << "./tracker: No files uploaded in group yet!" << endl;
                            string error_msg = "NO FILES IN GROUP";
                            write(client_socket, error_msg.c_str(), error_msg.size());
                        }
                        else {
                            int file_match = search_by_filename(files_in_group[group_id], file_name);

                            //File has not been previously uploaded
                            if(file_match == -1) {
                                cerr << "./tracker: This file has not been uploaded in group!" << endl;
                                string error_msg = "NO FILE";
                                write(client_socket, error_msg.c_str(), error_msg.size());
                            }
                            else {
                                int delete_index = search_by_string(files_in_group[group_id][file_match].user_ids, users[match].user_id);

                                //User has not uploaded or downloaded this file
                                if(delete_index == -1) {
                                    cerr << "./tracker: This file has not been uploaded/downloaded by this user in given group!" << endl;
                                    string error_msg = "HAS NOT SHARED";
                                    write(client_socket, error_msg.c_str(), error_msg.size());
                                }
                                //User has actually uploaded this group
                                else {
                                    //Deleting both user_id and file_path for given file corresponding to given user
                                    files_in_group[group_id][file_match].user_ids.erase(files_in_group[group_id][file_match].user_ids.begin() + delete_index);
                                    files_in_group[group_id][file_match].file_paths.erase(files_in_group[group_id][file_match].file_paths.begin() + delete_index);

                                    cout << "Client has stopped sharing " << file_name << " group " << group_id << "!" << endl;
                                    string success_msg = "STOPPED SHARING";
                                    write(client_socket, success_msg.c_str(), success_msg.size());
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

//SHOW_DOWNLOADS
void show_downloads(int client_socket, vector<string> command_list) {
    string listening_IP = get_IP_from(command_list[0]);
    int listening_port = stoi(get_port_from(command_list[0]));

    {
        lock_guard<mutex> lock(client_lock);    //Prevents multiple concurrent threads from changing stored data structures
        int match = search_by_address(users, listening_IP, listening_port);

        //Client does not have any login credentials
        if(match == -1) {
            cerr << "./tracker: No user assigned!" << endl;
            string error_msg = "NOT ASSIGNED";
            write(client_socket, error_msg.c_str(), error_msg.size());
        }
        else {
            //User has not logged in
            if(!(users[match].logged_in)) {
                cerr << "./tracker: User not logged in!" << endl;
                string error_msg = "NOT LOGGED IN";
                write(client_socket, error_msg.c_str(), error_msg.size());
            }
            else {
                cout << "Show downloads at client end!" << endl;
                string success_msg = "SHOW DOWNLOADS";
                write(client_socket, success_msg.c_str(), success_msg.size());
            }
        }
    }
}