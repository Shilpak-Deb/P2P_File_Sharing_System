#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "tracker.h"

using namespace std;

///Function to get port from socket details
string get_port_from(string socket_details) {
    int colon_pos;
    if(socket_details.rfind(':') != string::npos) {
        colon_pos = socket_details.rfind(':');
        return socket_details.substr(colon_pos + 1);
    }
    else {
        cerr << "./tracker: Invalid socket address!" << endl;
        exit(1);
    }
}

//Function to get IP address from socket details
string get_IP_from(string socket_details) {
    int colon_pos;
    if(socket_details.rfind(':') != string::npos) {
        colon_pos = socket_details.rfind(':');
        return socket_details.substr(0, colon_pos);
    }
    else {
        cerr << "./tracker: Invalid socket address!" << endl;
        exit(1);
    }
}

//Function to get file name from path
string get_filename_from(string file_path) {
    int slash_pos;
    if(file_path.rfind('/') != string::npos) {
        slash_pos = file_path.rfind('/');
        return file_path.substr(slash_pos + 1);
    }
    else {
        return file_path;
    }
}

//Function to assemble file_path from destination_path and file_name
string get_filepath_from(string destination_path, string file_name) {
    string file_path;
    if(destination_path[destination_path.size() - 1] == '/')  file_path = destination_path + file_name;
    else file_path = destination_path + "/" + file_name;

    return file_path;
}

//Function to read addresses of trackers from provided tracker_info file
vector<string> read_trackers(string tracker_info_file) {
    //Opening tracker_info file in read-only mode
    int tracker_info_fd = open(tracker_info_file.c_str(), O_RDONLY);

    //Checking if there is any error in opening the tracker_info_file
    if(tracker_info_fd == -1) {
        perror("./tracker: tracker_info_file");
        exit(1);
    }

    vector<string> trackers;    //Vector to store the data for the 2 trackers
    string record = "";         //Stores data inside tracker_info_file
    char buffer[BUFFER_SIZE];
    while(true) {
        int bytes_r = read(tracker_info_fd, buffer, BUFFER_SIZE);

        //Error in reading from tracker_info_file
        if (bytes_r == -1) {
            perror("tracker_info_file");
            close(tracker_info_fd);
            exit(1);
        }
        //End of file
        if (bytes_r == 0) break;

        //Stores the addresses of the trackers
        for (int i = 0; i < bytes_r; i++) {
            if (buffer[i] == '\n') {
                trackers.push_back(record);
                record.clear();
            } 
            else record += buffer[i];
        }
    }

    //If there's anything left in 'record', push it to 'trackers' (for the last line)
    if (!record.empty()) {
        trackers.push_back(record);
    }

    //Closing tracker_info_file
    close(tracker_info_fd);
    return trackers;
}

//Function to tokenize commands by whitespaces
vector<string> tokenize_commands(string commands) {
    if(commands.empty()) return {};   //Checks if string is empty
    vector<string> command_list;    //Stores all commands present in commands variable

    //Removing additonal ' ' from beginning of commands
    while(commands.at(0) == ' ') {
        commands = commands.substr(1);
    }

    //Tokenizing commands via ' '
    char* argument = strtok(commands.data(), " ");
    while(argument != NULL) {
        command_list.push_back(string(argument));
        argument = strtok(NULL, " ");
    }

    //Returning the string vector
    return command_list;
}

//Function to check if a user is already present in <User> vector
bool present_in(vector<User> vect, string user_id) {
    for(int i = 0; i < vect.size(); i++) {
        if(user_id == vect[i].user_id) {
            return true;
        }
    }
    return false;
}

//Function to check if a user is already present in <User> vector
bool present_in(vector<User> vect, string listening_IP, int listening_port) {
    for(int i = 0; i < vect.size(); i++) {
        if(listening_IP == vect[i].listening_IP && listening_port == vect[i].listening_port) {
            return true;
        }
    }
    return false;
}

//Function to return matching user from <User> vector
int search_by_id(vector<User>& vect, string user_id) {
    for(int i = 0; i < vect.size(); i++) {
        if(user_id == vect[i].user_id) {
            return i;
        }
    }
    return -1;
}

//Function to return matching user from <User> vector
int search_by_address(vector<User>& vect, string listening_IP, int listening_port) {
    for(int i = 0; i < vect.size(); i++) {
        if(listening_IP == vect[i].listening_IP && listening_port == vect[i].listening_port) {
            return i;
        }
    }
    return -1;
}

//Function to find all join requests by group_id
vector<string> search_requests_by(vector<string> requests, string group_id) {
    vector<string> matching_requests;

    for(int i = 0; i < requests.size(); i++) {
        vector<string> req_list = tokenize_commands(requests[i]);
        string id = req_list[2];
        if(group_id == id) matching_requests.push_back(req_list[0] + " " + req_list[1]);
    }

    return matching_requests;
}

//Function to return index of matching File_Details from a <File_Details> vector
int search_by_filename(vector<File_Details>& vect, string file_name) {
    for(int i = 0; i < vect.size(); i++) {
        if(file_name == vect[i].file_name) {
            return i;
        }
    }
    return -1;
}

//Function to return the index at which an element is found
int search_by_string(vector<string>& vect, string s) {
    for(int i = 0; i < vect.size(); i++) {
        if(s == vect[i]) {
            return i;
        }
    }
    return -1;
}



