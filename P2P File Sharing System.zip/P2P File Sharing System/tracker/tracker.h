#ifndef TRACKER_HEADER
#define TRACKER_HEADER

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

using namespace std;

//Header file to access the various user-created Tracker functions commands

//----------------------------------------------------------------------------------------------------------------------------------//

//User-defined data types:

//Structure to store the details of a user
struct User {
    string user_id;
    string password;
    string listening_IP;
    int listening_port;
    bool logged_in;
};

//Structure to store details of a file
struct File_Details {
    string file_name;
    long long file_size;            //File size in bytes
    vector<string> file_paths;      //File paths of the file in different clients (synced index)
    vector<string> user_ids;        //User IDs of the various clients that have the file (synced index)
};

//----------------------------------------------------------------------------------------------------------------------------------//

//External Global Variables

extern atomic<bool> is_running;     //Global atomic variable to check if the tracker is running

extern mutex client_lock;                                   //Global variable to protect the set of client sockets while concurrently running multiple server threads
extern map<string, vector<User>> groups;                    //Global variable to keep track of different groups by mapping them to a string Group ID 
extern vector<User> users;                                  //Keeps track of registered user(s) for the tracker
extern map<string, vector<string>> join_requests;           //Keeps track of all join requests (key value is user ID of owner)
extern map<string, vector<File_Details>> files_in_group;    //Keeps track of all uploaded files in group (key value is group ID)

//----------------------------------------------------------------------------------------------------------------------------------//

//Functions:

//misc.cpp
string get_port_from(string socket_details);
string get_IP_from(string socket_details);
string get_filename_from(string file_path);
string get_filepath_from(string destination_path, string file_name);
vector<string> read_trackers(string tracker_info_file);
vector<string> tokenize_commands(string commands);
bool present_in(vector<User> vect, string user_id);
bool present_in(vector<User> vect, string listening_IP, int listening_port);
int search_by_id(vector<User>& vect, string user_id);
int search_by_address(vector<User>& vect, string listening_IP, int listening_port);
vector<string> search_requests_by(vector<string> requests, string group_id);
int search_by_filename(vector<File_Details>& vect, string file_name);
int search_by_string(vector<string>& vect, string s);

//commands.cpp
void create_user(int client_socket, vector<string> command_list);
void login(int client_socket, vector<string> command_list);
void logout(int client_socket, vector<string> command_list);
void create_group(int client_socket, vector<string> command_list);
void list_groups(int client_socket, vector<string> command_list);
void leave_group(int client_socket, vector<string> command_list);
void join_group(int client_socket, vector<string> command_list);
void list_requests(int client_socket, vector<string> command_list);
void accept_request(int client_socket, vector<string> command_list);
void upload_file(int client_socket, vector<string> command_list);
void list_files(int client_socket, vector<string> command_list);
void download_file(int client_socket, vector<string> command_list);
void stop_share(int client_socket, vector<string> command_list);
void show_downloads(int client_socket, vector<string> command_list);

//----------------------------------------------------------------------------------------------------------------------------------//

#endif