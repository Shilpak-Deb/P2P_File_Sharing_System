#define BACKLOG 128                 //Stores maximum length of the queue for pending connections
#define BUFFER_SIZE 1024            //Stores buffer size for read operations (1024 bytes or 1 KB)
#define CHUNK_SIZE (512 * 1024)     //Chunk size (in bytes) for each file chunk  

#include <stdio.h>  //perror()
#include <iostream> //cin, cout, cerr
#include <string.h>     //strtok()
#include <unistd.h> //read(), write(), close()
#include <sys/stat.h> //stat()
#include <fcntl.h>  //open()
#include <arpa/inet.h>  //TCP communication
#include <sys/socket.h> //Socket creation
#include <thread>    //Multithreading
#include <mutex>    //Mutex locks
#include <errno.h>  //errno
#include <atomic>   //atomic 
#include <sys/select.h>  //select()

//Suppress deprecation warnings for SHA1 functions
#define OPENSSL_SUPPRESS_DEPRECATED
#include <openssl/sha.h>  //SHA1

#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "client.h"

using namespace std;


//Function to read from a particular tracker
bool read_from_tracker(int client_socket, string& message) {

    char buffer[BUFFER_SIZE];
    int bytes_r = read(client_socket, buffer, BUFFER_SIZE);
    
    if(bytes_r == -1) {
        perror("./client: Failed to read from tracker");
        return false;
    }

    message = "";
    for(int i = 0; i < bytes_r; i++) message += buffer[i];
    return true;
}

//Function to write to a particular tracker
bool write_to_tracker(int client_socket, string message) {

    if(write(client_socket, message.c_str(), message.size()) == -1) {
        perror("./client: Failed to write to tracker");
        return false;
    }
    return true;
}

//Function to create a listener socket (server socket) to start listening for other clients
int create_listener_socket() {
    string listener_IP = get_IP_from(listening_socket);
    int listener_port = stoi(get_port_from(listening_socket));

    int server_socket = socket(AF_INET, SOCK_STREAM, 0);    //Creating server socket (TCP)
    //Checking if listner socket has been created successfully
    if (server_socket == -1) {
        perror("./client: Listener socket creation failed");
        exit(1);
    }

    //Storing address of listener
    sockaddr_in server_address;
    server_address.sin_family = AF_INET;                                    //IPv4 addressing
    inet_pton(AF_INET, listener_IP.c_str(), &server_address.sin_addr);      //Assigns IP address for listener to listen from
    server_address.sin_port = htons(listener_port);                         //Assigns port no. for listener to listen from

    //Associates listener with listener address and port
    if(bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1) {
        perror("./client: Bind failed for listener socket");
        close(server_socket);
        exit(1);
    }

    //Places listener in passive listening state to accept incoming connections
    if (listen(server_socket, BACKLOG) == -1) {
        perror("./client: Listen failed for listener socket");
        close(server_socket);
        exit(1);
    }

    cout << "Client is listening on " << listening_socket << endl;

    return server_socket;
}

//Function to start listening on the client_listener_socket
void start_listening() {
    cout << "Listening for other clients" << endl;

    //Set timeout so that it can repeatedly check for new connections by going to the next iteration of the loop
    struct timeval timeout;
    timeout.tv_sec = 5;  //5 seconds
    timeout.tv_usec = 0;  //0 microseconds

    //Setting socket option so that socket can repeatedly check for new connections
    setsockopt(client_listener_socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));

    //----------------------------------------------------------------------------------------------------------------------------------//

    //Infinite loop (to continue listening for different other clients)
    while(true) {
        int client_socket = accept(client_listener_socket, NULL, NULL);
        //Error checking for if accept() operation fails
        if(client_socket < 0) {
            if(errno == EWOULDBLOCK || errno == EAGAIN) continue;
            else perror("./client: Failed to create socket to listen to other clients");
            continue;
        } 

        //Spawn a new thread to handle the client
        thread client_thread(talk_to_other_clients_as_server, client_socket);
        client_thread.detach();  //Detach client thread to allow for independent handling
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    close(client_listener_socket);   //Close the server socket
}

//Function to talk to other clients (acting as server)
void talk_to_other_clients_as_server(int other_client_socket) {
    char buffer[CHUNK_SIZE];

    //Infinite loop (to continue listening to that particular client)
    while(true) {
        //----------------------------------------------------------------------------------------------------------------------------------//

        int bytes_r = read(other_client_socket, buffer, BUFFER_SIZE);    //Keeps track of no. of bytes read from client socket
        if (bytes_r == -1 || bytes_r == 0) break;                        //Client socket has disconnected

        //----------------------------------------------------------------------------------------------------------------------------------//

        string message = "";    //Stores the commands provided by the client socket
        for(int i = 0; i < bytes_r; i++) message += buffer[i];
        vector<string> command_list = tokenize_commands(message);      //Storing all commands in a string vector

        //for(int i = 0; i < command_list.size(); i++) cout << command_list[i] << endl;

        string other_client_listening_socket_address = command_list[0];
        string command = command_list[1];

        if(command == "HASH") {
            string file_name = command_list[2];
            string file_path = command_list[3];
            message = "";
            
            for(int i = 0; i < file_hash[file_path].size(); i++) {
                message += file_hash[file_path][i] + " ";
            }

            //cout << "Writing hash details to other client" << endl;
            write(other_client_socket, message.c_str(), message.size());
        }
        else if(command == "FREQ") {
            string file_name = command_list[2];
            string file_path = command_list[3];
            message = "";

            //chunks_present has not been updated yet - i.e. no chunks present
            if(chunks_present.find(file_path) == chunks_present.end()) {
                for(int i = 0; i < file_hash[file_path].size(); i++) message += "0";
            }
            //Some chunks might already be present
            else {
                for(int i = 0; i < file_hash[file_path].size(); i++) {
                    if(chunks_present[file_path][i]) message += "1";
                    else message += "0";
                }
            }

            write(other_client_socket, message.c_str(), message.size());
        }
        else if(command == "DOWNLOAD") {
            string file_name = command_list[2];
            string file_path = command_list[3];
            long long chunk_index = stoll(command_list[4]);
            {
                lock_guard<mutex> lock(file_lock); 
                message = read_chunk_from_file(file_path, chunk_index);
            }
            write(other_client_socket, message.c_str(), message.size());
        }
    }
}

//Function to create new client socket (for talking to other clients' listener socket)
int create_client_socket(string other_client_listener_socket_address) {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);    //Creating a client socket to communicate with tracker
    //Checking if socket was created successfully
    if(client_socket == -1) {
        perror("./client: Client socket creation for listening to other clients failed");
        return -1;
    }

    //Setting socket option to allow reuse
    int opt = 1;
    if (setsockopt(client_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) == -1) {
        perror("./client: setsockopt() failed");
        close(client_socket);
        return -1;
    }

    int other_client_listening_port = stoi(get_port_from(other_client_listener_socket_address));
    string other_client_listening_IP = get_IP_from(other_client_listener_socket_address);

    //cout << "Connecting to other client at IP: " << other_client_listening_IP << " Port: " << other_client_listening_port << endl;

    //Storing address of tracker
    sockaddr_in other_client_listening_addr = {};
    other_client_listening_addr.sin_family = AF_INET;                               //IPv4 addressing
    other_client_listening_addr.sin_port = htons(other_client_listening_port);      //Assigns port no. for server to listen from

    //Assigns address of default tracker to tracker_addr
    if (inet_pton(AF_INET, other_client_listening_IP.c_str(), &other_client_listening_addr.sin_addr) <= 0) {
        perror("./client: Other client: Invalid address");
        close(client_socket);
        return -1;
    }

    //----------------------------------------------------------------------------------------------------------------------------------//

    //Checking if connection can be done
    int can_connect = connect(client_socket, (struct sockaddr *)&other_client_listening_addr, sizeof(other_client_listening_addr));
    if (can_connect == -1) {
        perror("./client: Failed to connect to other client");
        close(client_socket);
        return -1; 
    }

    return client_socket;
}

//Function to read from another client while acting as client (not server)
bool read_from_other_client_casual(int client_socket, string& message) {

    char buffer[CHUNK_SIZE];
    int bytes_r = read(client_socket, buffer, CHUNK_SIZE);
    
    if(bytes_r == -1) {
        perror("./client: Failed to read from other client");
        return false;
    }

    message = "";
    for(int i = 0; i < bytes_r; i++) message += buffer[i];

    return true;
}

//Function to read from another client while acting as client (not server)
bool read_from_other_client(int client_socket, long long chunk_size, string& message) {

    char buffer[CHUNK_SIZE];
    long long total = 0;
    long long bytes_r;

    while(total < chunk_size) {
        bytes_r = read(client_socket, buffer + total, chunk_size - total); //Read into the correct position

        if(bytes_r == -1) {
            perror("./client: Failed to read from other client");
            return false;
        }
        else if(bytes_r == 0) break;

        total += bytes_r;
    }
    
    message = "";
    for(int i = 0; i < chunk_size; i++) message += buffer[i];

    return true;
}

//Function to write to another client while acting as client (not server)
bool write_to_other_client(int client_socket, string message) {

    if(write(client_socket, message.c_str(), message.size()) == -1) {
        perror("./client: Failed to write to tracker");
        return false;
    }
    return true;
}

